// https://en.kinorium.com/user/684420/diary/?company_type=production&perpage=200&order=date
[...document.querySelectorAll('.poster')].map(a => a.querySelector('img').src)
