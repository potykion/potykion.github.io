// https://craftbeer78.ru/brewery/velka-morava

[...document.querySelectorAll('.beer_logo img')].map(i => i.src)
