---
title: Ярик Врыв 
desc: 'Врыв в Ярик на пару дней, чисто пожрать, как обычно' 
---

## План 

### День 1 (тупа вечер)

- [**Пенаты**](https://yandex.ru/maps/-/CDRlYS53) - необычная подача (выебоны): эволюция борща

### День 2 (денек)

- [Утро](https://yandex.ru/maps/-/CDRlYG4c) - завтраки
- [Достопримечательности в Ярославле: 13 любопытных мест](https://yandex.ru/maps/discovery/podborka_chto-posmotret-dostoprimechatel-nosti_yaroslavl-16/?ll=39.867594%2C57.653274&z=12)
- Бородатый топор - метание топоров
- Пряничный домик
- [Мамука](https://yandex.ru/maps/-/CDBoiYoo) - грузия
- [Собрание](https://yandex.ru/maps/-/CDRlYZOz) - русская


---

## Идеи

### По категориям

#### Русская

- [Ванильное небо](https://yandex.ru/maps/-/CDRlYR06) - русская + вид класс
- [Русская охота](https://yandex.ru/maps/-/CDRlYS2J) - русская: котлета из медведя, дичь
- [Собинов](https://yandex.ru/maps/-/CDRlYSON) - русская: пельмени
- [Пенаты](https://yandex.ru/maps/-/CDRlYS53) - необычная подача (выебоны): эволюция борща
- [Дежавю](https://yandex.ru/maps/-/CDRl4MOC) - старый борщ [Вася]
- [Иоанн Васильевич](https://yandex.ru/maps/-/CDeejRLw) - русская
- [Собрание](https://yandex.ru/maps/-/CDRlYZOz) - русская
- [Кумушка](https://yandex.ru/maps/-/CDRlYCNY) - русская

#### Завтраки

- [Арабуста](https://yandex.ru/maps/-/CDRl4QPX) - завтраки
- [Багет, паштет и желтый плед](https://yandex.ru/maps/-/CDRlYJ7o) - универсал (**завтраки**, обеды, ужины)
- [Утро](https://yandex.ru/maps/-/CDRlYG4c) - завтраки

#### Бары / пивнухи

- [Dudki](https://yandex.ru/maps/-/CDeOuDks) - бухать
- [Hopmalt](https://yandex.ru/maps/-/CDahuJ0i) - пиво
- [Афоня](https://yandex.ru/maps/-/CDRlYH4h) - бухать
- [Папин гараж](https://yandex.ru/maps/-/CDuW60IN) - бухать
- [Пинта](https://yandex.ru/maps/-/CDRlYL2s) - пиво
- [Разлука](https://yandex.ru/maps/-/CDR3NBL7) - крафтовуха

#### Недорогая

- [Bazar](https://yandex.ru/maps/org/bazar/220391392409/?ll=39.869876%2C57.628543&z=14) - столовка 

#### Грузия

- [Мамука](https://yandex.ru/maps/-/CDBoiYoo) - грузия

#### Универсал

- [IZI kitchen](https://yandex.ru/maps/-/CDqfnU3Z) - универсал (завтраки, обеды, ужины)

#### Италия

- [Союз Писателей](https://yandex.ru/maps/-/CDRlYG-K) - универсал (завтраки, обеды, ужины), но больше италия: пицца, паста
- [Остерия Лючия](https://yandex.ru/maps/-/CDUheJjJ) - италия
- [Траттория Четыре сыра](https://yandex.ru/maps/-/CDRlYCi3) - италия

---

### 100 мест где поесть

- [Русская охота](https://yandex.ru/maps/-/CDRlYS2J) - русская: котлета из медведя, дичь
- [Ванильное небо](https://yandex.ru/maps/-/CDRlYR06) - русская
- [Собинов](https://yandex.ru/maps/-/CDRlYSON) - русская 
- [Пенаты](https://yandex.ru/maps/-/CDRlYS53) - необычная подача (выебоны)

- [Арабуста](https://yandex.ru/maps/-/CDRl4QPX) - завтраки

- [Dudki](https://yandex.ru/maps/-/CDeOuDks) - бухать
- [Bazar](https://yandex.ru/maps/org/bazar/220391392409/?ll=39.869876%2C57.628543&z=14) - столовка 
- [Башня](https://yandex.ru/maps/-/CDRlYWmz) - камбала
- [Фанкафе](https://yandex.ru/maps/-/CDRl4Upq) - корейская 
- [Бурум](https://yandex.ru/maps/org/burum/1755904134/?ll=39.882769%2C57.626988&z=16) - шава

#### Посетить

- Бородатый топор - метание топоров
- Пряничный домик

### ЯКарты и другое

- [Дежавю](https://yandex.ru/maps/-/CDRl4MOC) - старый борщ [Вася]
- [Мамука](https://yandex.ru/maps/-/CDBoiYoo) - грузия
- [Багет, паштет и желтый плед](https://yandex.ru/maps/-/CDRlYJ7o) - универсал (**завтраки**, обеды, ужины)
- [IZI kitchen](https://yandex.ru/maps/-/CDqfnU3Z) - универсал (завтраки, обеды, ужины)
- [Союз Писателей](https://yandex.ru/maps/-/CDRlYG-K) - универсал (завтраки, обеды, ужины)
- [Иоанн Васильевич](https://yandex.ru/maps/-/CDeejRLw) - русская
- [Собрание](https://yandex.ru/maps/-/CDRlYZOz) - русская
- [Остерия Лючия](https://yandex.ru/maps/-/CDUheJjJ) - италия
- [Траттория Четыре сыра](https://yandex.ru/maps/-/CDRlYCi3) - италия
- [Кумушка](https://yandex.ru/maps/-/CDRlYCNY) - русская
- [Утро](https://yandex.ru/maps/-/CDRlYG4c) - завтраки
- [Hopmalt](https://yandex.ru/maps/-/CDahuJ0i) - пиво
- [Афоня](https://yandex.ru/maps/-/CDRlYH4h) - бухать
- [Папин гараж](https://yandex.ru/maps/-/CDuW60IN) - бухать
- [Пинта](https://yandex.ru/maps/-/CDRlYL2s) - пиво

#### Посетить

- [Достопримечательности в Ярославле: 13 любопытных мест](https://yandex.ru/maps/discovery/podborka_chto-posmotret-dostoprimechatel-nosti_yaroslavl-16/?ll=39.867594%2C57.653274&z=12)