---
title: Теилвинд лав
created: 2024-01-14 19:13
---


Ля люблю <a href="https://tailwindcss.com/">Tailwind CSS</a>


(ооо меня поперло, ща будет 10 постов в минуту)


Просто потому что он является квинтэссенцией (хах это слово конечно не с первого раза написал) тулов для
    программистов
    - а именно он поощряет лень.

То есть вместо того чтобы из раза в раз писать <code>display: flex; justify-content: center</code> - просто пишешь
    <code>class="flex
        justify-center"</code>. Типа в том, чтобы написать <code>display</code> нет ничего сложного, но лень же)) 

Осталось упростить процесс установки с <code>установи > сгенерь конфиг > поправь конфиг > сделай css-файл > выполни
    команду > начинай юзать</code>
    до <code>установи > начинай юзать</code>. Хотя уже в планах:


<iframe src="https://www.youtube.com/embed/CLkxRnRQtDE?si=CY7IukoQ8rQDNhFF&amp;start=2146"
        title="YouTube video player" frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen></iframe>
