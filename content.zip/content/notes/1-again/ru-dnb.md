---
title: Рашн днб
created: 2024-01-14 12:18
---


Весь прошлы год слушал рашн днб, и, оказывается, до сих очень много движухи по этой тематике.



Сначала я просто гонял какие-то дженерик подборки на ют, какие-то ноунейм каналы, а потом как наткнулся
    на <a
        href="https://neuropunk.ru">Neuropunk Records</a> и офигел. Это крч и лейбл, и стримы, и
    фестивали, и свой лор, свое приложение - целый мир, которому уже больше 20 лет! но обо всем по порядку


Многие, как я думал, зарубежные артисты на самом деле русские п<b>а</b>рики: Gydra,
    Tobax,
    Nais, Teddy Killers - все наши. И все в днб среде друг-друга знают, и наши и ваши, все друг с другом коллабятся
    и при этом
    вся эта темка остается в
    андере, вот ето круть. Взять например René LaVice - канадский челик, а есть фит с Гидрой 

<iframe src="https://www.youtube.com/embed/56BVQOVUvUw?si=yHTG-A_ZIFz6lCQM"
        title="YouTube video player" frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen></iframe>


Потом про фесты - они проходят <b>несколько раз в год</b>, и это независимо от ковида/войнушки, и это только
    от Нейропанк, и это только в мск/питере, а еще они колесят по РФии, а еще есть <a
        href="https://vk.com/worldofdrumandbass">World of Drum and Bass</a>, которому
    тоже солидно годков - <a href="https://www.youtube.com/watch?v=nM-yzRbwAeY&t=1325s">15</a>:

<iframe src="https://www.youtube.com/embed/8WmRTsyrdOo?si=-mhqXu1pY32HCvCR"
        title="YouTube video player" frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen></iframe>


В детстве, когда не шарил за драм и слушал всякий метал, помню была только Пиратская Станция (а она тоже до сих
    пор
    проходит), а сейчас и глобальных-масштабных фестов
    несколько, и локальные движухи есть, типа <a href="https://etdnb.ru/">Elephant Trunk</a>, и в онлайне куча транс


Так на <a href="https://www.youtube.com/@neuropunk">ютуб канале Нейропанк</a> каждую неделю проходит от одной до
    нескольких трансляций, и все тематические:

<ul>
    <li>Есть DropDealers - где выступают молодые диджеи</li>
    <li>Есть Что было раньше (не дальше) - где ставят олдовый драмчик</li>
    <li>Есть Нейрогон - где батьки Бес и Пейперклип <i>разносят кабину</i> под мемы</li>
</ul>

Мемы тоже ржекельные, например молодой дуэт IronType исковеркали в <a
        href="https://youtube.com/shorts/lG4bhJlRg-U?si=vGTS7SANNAgBdXBS">Айран Тан</a>, а некоторые треки содержат
    в себе
    "<a href="https://www.youtube.com/@LetItRollfestival">let it roll</a>... цезарь ролл... и бигмак" - ржачная
    темка крч

Че еще не рассказал? А, собсно по музыке и аппу, Нейропанк - это большущий лейбл, так что можно найти исполнителя
    себе по душе,
    плюс недавно еще появился саб-лейбл - Костер, где исполняют драм с русским вокалом,
    и все это можно послушать в
    <b>самописном</b> <a href="https://neuropunk.app/">приложении</a> со <b>своим биллингом</b>, и этот биллинг
    внедрен на стримы, где можно донатить через телеграм - оч технологично! 

